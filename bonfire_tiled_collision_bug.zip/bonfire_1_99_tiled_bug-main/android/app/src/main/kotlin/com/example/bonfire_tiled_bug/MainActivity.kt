package com.example.bonfire_tiled_bug

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
